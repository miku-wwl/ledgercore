\pset pager off
SELECT 'observed_at' AS item, clock_timestamp() AS value;
SELECT operation_id,payment_id,external_status,intent_digest,amount_minor,inquiry_count,simulator_reference FROM simulator_operations WHERE operation_id='c28b7080-d808-471c-a2aa-d35cb66eadcc'::uuid;
SELECT callback_id,sequence_no,external_status,delivery_status,attempt_count,created_at,delivered_at,last_error FROM simulator_callback_outbox WHERE operation_id='c28b7080-d808-471c-a2aa-d35cb66eadcc'::uuid ORDER BY sequence_no;
